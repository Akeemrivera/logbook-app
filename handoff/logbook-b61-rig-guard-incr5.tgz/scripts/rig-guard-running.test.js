'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const guard = require('./rig-guard-running.js');

const FAIL = [];
function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

const finder = { name: 'Finder', bundleId: 'com.apple.Finder', path: '/System/Applications/Finder.app', bundleIds: [] };

function obs(extraLs, extraSe) {
  return {
    lsappinfo: { ok: true, complete: true, apps: [finder].concat(extraLs || []) },
    systemEvents: { ok: true, complete: true, apps: [finder].concat(extraSe || []) },
  };
}

check('nothing identified as production is clear', guard.decide(obs()).ok === true);
check('exact production bundle id blocks', guard.decide(obs([], [{ name: 'App', bundleId: guard.PROD, path: '/private/var/folders/x/App' }])).ok === false);
check('QA bundle id does not count as production', guard.decide(obs([], [{ name: 'Borikèn Logbook QA', bundleId: guard.QA, path: '/Applications/Borikèn Logbook QA.app' }])).ok === true);
check('a longer id is not treated as the production id', guard.isProd(guard.QA) === false && guard.isQa(guard.QA) === true);

const renamed = { name: 'Garden Notes', bundleId: guard.PROD, path: '/Users/a/Applications/Garden Notes.app', bundleIds: [] };
check('a renamed app still blocks when its bundle id is production', guard.decide(obs([renamed])).reason === 'production Logbook is running');

const nfd = 'Borike\u0300n Logbook';
check('an accent-decomposed Logbook name with no bundle id blocks', guard.decide(obs([], [{ name: nfd, bundleId: '', path: '/Applications/' + nfd + '.app' }])).ok === false);
check('the same decomposed name is clear when the bundle id is QA', guard.decide(obs([], [{ name: nfd, bundleId: guard.QA, path: '/Applications/' + nfd + '.app' }])).ok === true);

const wrapper = '/Users/a/Applications/Boriken Logbook.app/Wrapper/App.app/App';
check('an iOS-on-Mac wrapper path with the production id blocks even without the display name in argv', guard.decide(obs([{ name: 'App', bundleId: guard.PROD, path: wrapper }])).ok === false);
check('the same wrapper path is clear for the QA id', guard.decide(obs([{ name: 'App', bundleId: guard.QA, path: wrapper }])).ok === true);
check('Logbook.app with no readable bundle id blocks', guard.decide(obs([], [{ name: 'App', bundleId: '', path: '/Applications/Logbook.app' }])).ok === false);
check('Logbook.app with a different readable bundle id is clear', guard.decide(obs([], [{ name: 'App', bundleId: 'com.example.other', path: '/Applications/Logbook.app' }])).ok === true);
check('the production container path blocks', guard.decide(obs([], [{ name: 'App', bundleId: '', path: '/Users/a/Library/Containers/' + guard.PROD + '/Data' }])).ok === false);
check('the QA container path does not block by itself', guard.decide(obs([], [{ name: 'App', bundleId: guard.QA, path: '/Users/a/Library/Containers/' + guard.QA + '/Data' }])).ok === true);
check('production id in only one of the two lists blocks', guard.decide(obs([{ name: 'App', bundleId: guard.PROD, path: wrapper }], [])).ok === false);
check('a failed lsappinfo query blocks', guard.decide({ lsappinfo: { ok: false, complete: false, apps: [] }, systemEvents: obs().systemEvents }).reason === 'running-app identity uncertain: lsappinfo');
check('a failed System Events query blocks', guard.decide({ lsappinfo: obs().lsappinfo, systemEvents: { ok: false, complete: false, apps: [] } }).reason === 'running-app identity uncertain: system-events');
check('an empty successful-looking query is still uncertain', guard.decide({ lsappinfo: { ok: true, complete: false, apps: [] }, systemEvents: obs().systemEvents }).reason === 'running-app identity uncertain: lsappinfo');

const wrapperPath = '/private/var/folders/x/d/Wrapper/App.app/App';
const listed = [
  '90) ASN:0x0-0x10:',
  '    pid = 10',
  '91) "App" ASN:0x0-0x20:',
  '    bundleID="' + guard.PROD + '"',
  '    executable path="' + wrapperPath + '"',
  '92) "com.apple.WebKit.WebContent" ASN:0x0-0x30:',
].join('\n');
const parsedLive = guard.parseLsappinfo(listed);
check('a nameless lsappinfo row does not hide a parsed production bundle id', parsedLive.complete === true && parsedLive.apps.some((app) => app.bundleId === guard.PROD));
check('production id plus an incomplete System Events query still blocks as production', guard.decide({
  lsappinfo: parsedLive,
  systemEvents: { ok: false, complete: false, apps: [], error: 'osascript failed' },
}).reason === 'production Logbook is running');
check('the iOS-on-Mac var/folders wrapper blocks when the bundle id is production', guard.decide(obs([{ name: 'App', bundleId: guard.PROD, path: wrapperPath }])).reason === 'production Logbook is running');
check('AutoFill helper name with the Safari helper bundle id does not block', guard.decide(obs([], [{
  name: 'AutoFill (Borikèn Logbook)',
  bundleId: 'com.apple.SafariPlatformSupport.Helper',
  path: '/System/Library/PrivateFrameworks/SafariPlatformSupport.framework/Versions/A/XPCServices/com.apple.SafariPlatformSupport.Helper.xpc',
}])).ok === true);
check('that helper name is not the Logbook name heuristic', guard.suspect({ name: 'AutoFill (Borikèn Logbook)', path: '', bundleId: '' }) === false);
check('uppercase production id blocks', guard.decide(obs([], [{ name: 'App', bundleId: guard.PROD.toUpperCase(), path: '/tmp/App' }])).ok === false);

const parsed = guard.parseLsappinfo([
  '1) "App" ASN:0x0-0x1:',
  '    bundleID="' + guard.PROD + '"',
  '    bundle path="' + wrapper + '"',
].join('\n'));
check('lsappinfo text for the wrapper resolves to production', parsed.complete === true && guard.decide({ lsappinfo: parsed, systemEvents: obs().systemEvents }).ok === false);

const events = guard.parseSystemEvents(guard.QA + '\t/Applications/Boriken Logbook QA.app\tBoriken Logbook QA\n');
check('system events rows parse bundle id, path, and name', events.complete === true && events.apps[0].bundleId === guard.QA);
check('a short system events row is uncertain', guard.parseSystemEvents('only-one-field\n').ok === false);

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rig-guard-'));
const renamedApp = path.join(root, 'Garden Notes.app');
const wrapperApp = path.join(root, 'Boriken Logbook.app', 'Wrapper', 'App.app');
fs.mkdirSync(path.join(renamedApp, 'Contents'), { recursive: true });
fs.mkdirSync(wrapperApp, { recursive: true });
const plist = (id) => `<?xml version="1.0" encoding="UTF-8"?>\n<plist version="1.0"><dict><key>CFBundleIdentifier</key><string>${id}</string></dict></plist>\n`;
fs.writeFileSync(path.join(renamedApp, 'Contents', 'Info.plist'), plist(guard.PROD));
fs.writeFileSync(path.join(wrapperApp, 'Info.plist'), plist(guard.QA));
check('a renamed bundle path reads the production id from its plist', guard.bundleIdsAlong(renamedApp).includes(guard.PROD));
check('an iOS-on-Mac wrapper path reads the inner Info.plist', guard.bundleIdsAlong(path.join(wrapperApp, 'App')).includes(guard.QA));

const script = fs.readFileSync(path.join(__dirname, '..', 'rig-guard.sh'), 'utf8');
check('the guard no longer treats a display-name path search as proof the app is closed', !script.includes('pgrep'));
check('the guard asks the running-app check and does not quit or launch an app', script.includes('scripts/rig-guard-running.js') && !/killall|osascript/.test(script));

function spawnResult(spec) {
  return () => spec;
}
function scriptedSpawn(byCmd) {
  const calls = [];
  const spawn = (cmd) => {
    calls.push(cmd);
    const spec = byCmd[cmd];
    if (!spec) return { error: Object.assign(new Error('spawn ' + cmd + ' ENOENT'), { code: 'ENOENT' }), status: null, stdout: '' };
    return spec;
  };
  spawn.calls = calls;
  return spawn;
}
const finderRow = 'com.apple.Finder\t/System/Applications/Finder.app\tFinder';
const missing = scriptedSpawn({});
const missingObs = guard.collectLive(missing);
check('a missing lsappinfo and osascript fail closed', missing.calls.join(',') === 'lsappinfo,osascript' && guard.exitCode(guard.decide(missingObs)) === 4 && missingObs.lsappinfo.ok === false && missingObs.systemEvents.ok === false, guard.decide(missingObs).reason);
check('that missing-tool result names both lookups', guard.decide(missingObs).reason === 'running-app identity uncertain: lsappinfo, system-events', guard.decide(missingObs).reason);

const unusable = scriptedSpawn({
  lsappinfo: { status: 0, stdout: 'not a bundle list\n' },
  osascript: { status: 1, error: new Error('osascript failed'), stdout: '' },
});
const unusableObs = guard.collectLive(unusable);
check('unusable lookup text fails closed without asking the real tools', guard.decide(unusableObs).reason === 'running-app identity uncertain: lsappinfo, system-events', guard.decide(unusableObs).reason);

const prodStdout = '91) "App" ASN:0x0-0x20:\n    bundleID="' + guard.PROD + '"\n    executable path="/private/var/folders/x/d/Wrapper/App.app/App"\n';
const prodDespiteFailure = scriptedSpawn({
  lsappinfo: { status: 1, error: new Error('lsappinfo failed'), stdout: prodStdout },
  osascript: { error: Object.assign(new Error('spawn osascript ENOENT'), { code: 'ENOENT' }), status: null, stdout: '' },
});
check('a production bundle id in a failed lsappinfo result still blocks', guard.decide(guard.collectLive(prodDespiteFailure)).reason === 'production Logbook is running');

const clearTools = scriptedSpawn({
  lsappinfo: { status: 0, stdout: '1) "Finder" ASN:0x0-0x1:\n    bundleID="com.apple.Finder"\n    bundle path="/System/Applications/Finder.app"\n' },
  osascript: { status: 0, stdout: finderRow + '\n' },
});
check('synthetic clear lookups report no production Logbook and exit 0', guard.decide(guard.collectLive(clearTools)).reason === 'no production Logbook identified' && guard.exitCode(guard.decide(guard.collectLive(clearTools))) === 0);

const suite = fs.readFileSync(__filename, 'utf8').split('\n').filter((line) => !line.includes('suite does not spawn'));
check('suite does not spawn the real checker or the Mac lookup tools', !suite.some((line) => line.includes('spawnSync')));

if (FAIL.length) {
  console.error(FAIL.length + ' failed');
  process.exit(1);
}
console.log('rig guard running checks passed');
