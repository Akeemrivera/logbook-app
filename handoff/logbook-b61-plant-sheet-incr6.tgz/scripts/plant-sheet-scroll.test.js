'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.env.LOGBOOK_ROOT || path.join(__dirname, '..');
const FAIL = [];
function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'build59.css'), 'utf8');
const js = fs.readFileSync(path.join(ROOT, 'build59.js'), 'utf8');
const form = html.slice(html.indexOf('id="plant-modal"'), html.indexOf('id="sync-recovered-modal"'));

check('Save plant is inside the plant dialog after Notes', form.indexOf('id="plant-notes"') < form.indexOf('>Save plant<') && form.includes('class="button-row modal-actions"'));
check('the sheet box is capped at the viewport, not only the visual-viewport variable', /dialog\.modal \{[\s\S]*max-height: min\(/.test(css) && css.includes('calc(100% - env(safe-area-inset-top) - env(safe-area-inset-bottom) - 16px)'));
check('the dialog box does not scroll itself', /dialog\.modal \{[\s\S]*overflow: hidden;/.test(css));
check('the card inside the dialog is the scroller', /dialog\.modal > \.modal-card \{[\s\S]*min-height: 0;[\s\S]*overflow-y: auto;/.test(css));
check('the page lock is unchanged', js.includes("b.style.position = 'fixed'") && js.includes("classList.add('b59-locked')") && js.includes('window.scrollTo = function'));
check('focus brings a button into the sheet, not only text fields', js.includes("t.matches('input, select, textarea, button')"));

if (FAIL.length) {
  console.error(FAIL.length + ' failed');
  process.exit(1);
}
console.log('plant sheet scroll checks passed');
