/* Build 59 (Elio, Nov 3 2026):
   1. Family tree partner row (build57.js fam()): this plant and the plant it was bred with side by side, × badge, bracket to Kids.
   2. Tree kids are seed offspring only; "Kids & clones" is now "Kids" (build57.js kids()).
   3. Duplicate kid: a cross and the plant grown from it showed as two kids. build49 children() now dedupes by id / cross link;
      this file adds a safe migration that stores the cross link (b49ProjectId) when exactly one cross matches. Nothing deleted.
   4. Sheets: background page locked while any sheet / modal / picker is open (scroll position saved and restored,
      overscroll-behavior: contain, iOS touchmove guard); the sheet scrolls with momentum, safe-area max-height, keyboard aware.
      Stacked sheets unlock only when the last one closes.
   5. Family tree button passes the profile's real key (mf profiles were sent as pl:<id>) and the tree resolves keys by id.
   6. Tab bar: equal icon size, one label baseline, evenly spaced tabs (build59.css + new Lineage tab icon). */
(function () {
  'use strict';
  /* ---------- 3. migration: link a plant to the cross it was grown from (id first, exactly one cross by parents) ---------- */
  const LOG = [];
  function migrate() {
    if (!window.B49 || !B49.seedOf) return 0; let n = 0;
    const prs = (state.breedingProjects || []).filter((p) => p.status !== 'Archived');
    [['pl', state.plants], ['bp', state.breedingPlants]].forEach(([t, a]) => (a || []).forEach((r) => {
      if (!r || r.b59Mig === 1) return; r.b59Mig = 1;
      if (r.b49ProjectId || r.promotedFrom || r.source === 'clone' || (typeof isClonePlant === 'function' && isClonePlant(r))) return;
      if (r.b58Manual && (r.b58Manual.m || r.b58Manual.f)) return; /* hand links win */
      if (B49.projFor && B49.projFor(r)) return;
      const k = `${t}:${r.id}`; const hit = prs.filter((p) => B49.seedOf(`pr:${p.id}`, k));
      if (hit.length === 1) { r.b49ProjectId = hit[0].id; r.b59LinkedAt = new Date().toISOString(); LOG.push(`${r.name}: linked to cross "${hit[0].name || hit[0].id}" (same parents)`); n++; }
      else if (hit.length > 1) LOG.push(`${r.name}: same parents as ${hit.length} crosses; left unlinked`);
    }));
    try { const old = JSON.parse(localStorage.getItem('b59-migration-log') || '[]'); localStorage.setItem('b59-migration-log', JSON.stringify([...old, ...LOG.map((m) => `${new Date().toISOString()} ${m}`)].slice(-400))); } catch (e) { /* */ }
    try { window.__b57inval && __b57inval(); } catch (e) { /* */ }
    return n;
  }
  try { if (migrate()) saveState(); } catch (e) { console.warn('b59 migrate', e); }

  /* ---------- 4. sheet scroll lock ---------- */
  const SHEETS = 'dialog[open], .b58-sheet, [aria-modal="true"]';
  const openSheets = () => [...document.querySelectorAll(SHEETS)].filter((e) => e.isConnected && (e.tagName === 'DIALOG' ? e.open : e.offsetParent !== null || getComputedStyle(e).position === 'fixed'));
  let locked = false, saved = 0, depth = 0;
  function lock() { if (locked) return; locked = true; saved = window.scrollY || document.documentElement.scrollTop || 0; const b = document.body;
    b.dataset.b59y = String(saved); b.style.position = 'fixed'; b.style.top = `-${saved}px`; b.style.left = '0'; b.style.right = '0'; b.style.width = '100%'; b.style.overflow = 'hidden';
    document.documentElement.classList.add('b59-locked'); }
  function unlock() { if (!locked) return; locked = false; const b = document.body; const y = Number(b.dataset.b59y || saved) || 0;
    ['position', 'top', 'left', 'right', 'width', 'overflow'].forEach((p) => { b.style[p] = ''; }); delete b.dataset.b59y; document.documentElement.classList.remove('b59-locked');
    const se = document.documentElement.style.scrollBehavior; document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, y); document.documentElement.style.scrollBehavior = se; }
  function sync() { const n = openSheets().length; depth = n; if (n > 0) lock(); else unlock(); }
  /* while locked, page code that scrolls the window (scrollTo(0, 0) on navigation) moves the saved position instead */
  const _st = window.scrollTo.bind(window); window.scrollTo = function (x, y) { if (locked) { const t = typeof x === 'object' && x ? x.top : y; if (typeof t === 'number') { saved = t; document.body.dataset.b59y = String(t); } return; } return _st.apply(window, arguments); };
  ['showModal', 'show', 'close'].forEach((m) => { const o = HTMLDialogElement.prototype[m]; if (!o) return; HTMLDialogElement.prototype[m] = function () { const x = o.apply(this, arguments); sync(); return x; }; });
  new MutationObserver(() => sync()).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['open', 'aria-modal', 'hidden'] });
  document.addEventListener('close', sync, true); document.addEventListener('cancel', () => setTimeout(sync, 0), true);
  /* iOS: a touch that is not inside a scrollable part of the top sheet never scrolls the page (and never chains at the edges) */
  const top = () => { const s = openSheets(); return s[s.length - 1] || null; };
  const scrollable = (el, stop) => { for (let e = el; e && e !== stop.parentElement; e = e.parentElement) { const cs = getComputedStyle(e); if (/(auto|scroll)/.test(cs.overflowY) && e.scrollHeight > e.clientHeight + 1) return e; } return null; };
  let y0 = 0; document.addEventListener('touchstart', (e) => { y0 = e.touches[0] ? e.touches[0].clientY : 0; }, { passive: true, capture: true });
  document.addEventListener('touchmove', (e) => { if (!locked || e.touches.length > 1) return; const t = top(); if (!t) return;
    if (!t.contains(e.target)) { e.preventDefault(); return; } const sc = scrollable(e.target, t); if (!sc) { if (e.cancelable) e.preventDefault(); return; }
    const dy = (e.touches[0] ? e.touches[0].clientY : 0) - y0; const atTop = sc.scrollTop <= 0, atBot = sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 1;
    if (((atTop && dy > 0) || (atBot && dy < 0)) && e.cancelable) e.preventDefault(); }, { passive: false, capture: true });
  /* keyboard: the sheet's max height follows the visible viewport; a focused field scrolls into view */
  const vv = window.visualViewport; const setVh = () => { const h = vv ? vv.height : window.innerHeight; document.documentElement.style.setProperty('--b59-vvh', `${Math.round(h)}px`); };
  setVh(); if (vv) { vv.addEventListener('resize', setVh); vv.addEventListener('scroll', setVh); } window.addEventListener('resize', setVh);
  document.addEventListener('focusin', (e) => { const t = e.target; if (!locked || !t || !t.matches || !t.matches('input, select, textarea, button')) return; const s = top(); if (!s || !s.contains(t)) return; setTimeout(() => { try { t.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (err) { /* */ } }, 320); });
  sync();

  /* ---------- 6. tab bar: new Lineage icon drawn to the same 32-unit box as the other tab icons ---------- */
  const LIN = '<svg class="ci" viewBox="0 0 32 32" aria-hidden="true"><rect x="3" y="3.5" width="10" height="9" rx="3" fill="#e0a64a" stroke="#9a6a22" stroke-width="1.3"/><rect x="19" y="3.5" width="10" height="9" rx="3" fill="#6fb37a" stroke="#3d7d4a" stroke-width="1.3"/><path d="M8 12.5v4.5h16v-4.5M16 17v4.5" fill="none" stroke="#8a5a2c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="16" cy="25" r="4.6" fill="#c97b3a" stroke="#86501f" stroke-width="1.3"/></svg>';
  function tabIcon() { const b = document.querySelector('#tabbar [data-tab-view="lineage"]'); if (b && !b.dataset.b59) { const s = b.querySelector('svg'); if (s) s.outerHTML = LIN; b.dataset.b59 = '1'; } const bar = document.getElementById('tabbar'); if (bar) bar.classList.add('b59-tabs'); }
  tabIcon(); setInterval(tabIcon, 400);

  window.B59 = { migrate, migLog: LOG, sync, openSheets, isLocked: () => locked, depth: () => depth };
})();
