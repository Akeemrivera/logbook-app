'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.env.HARNESS_ROOT || path.join(__dirname, '..');
const FAIL = [];

function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

const pbx = fs.readFileSync(path.join(ROOT, 'ios/App/App.xcodeproj/project.pbxproj'), 'utf8');
const scheme = fs.readFileSync(path.join(ROOT, 'ios/App/App.xcodeproj/xcshareddata/xcschemes/App-QA.xcscheme'), 'utf8');
const swift = fs.readFileSync(path.join(ROOT, 'ios/App/LogbookQAUITests/LogbookQAUITests.swift'), 'utf8');
const runner = fs.readFileSync(path.join(ROOT, 'scripts/run-qa-uitest.sh'), 'utf8');

check('runner bundle is the QA UI test id', pbx.includes('PRODUCT_BUNDLE_IDENTIFIER = com.borikengenetics.logbookapp.qa.uitests;'));
check('QA app bundle stays com.borikengenetics.logbookapp.qa', pbx.includes('PRODUCT_BUNDLE_IDENTIFIER = com.borikengenetics.logbookapp.qa;'));
check('production bundle remains on the app target', (pbx.match(/PRODUCT_BUNDLE_IDENTIFIER = com\.borikengenetics\.logbookapp;/g) || []).length >= 2);
check('UI test target names App and does not set TEST_HOST', (pbx.match(/TEST_TARGET_NAME = App;/g) || []).length === 3 && !pbx.includes('TEST_HOST') && !pbx.includes('RUNTIME_TEST_HOST') && pbx.includes('com.apple.product-type.bundle.ui-testing'));
check('team is 2Z94YL957X', pbx.includes('DEVELOPMENT_TEAM = 2Z94YL957X;'));
check('UI test target has a QA configuration', pbx.includes('QAUITEST0000000000000C /* QA */'));
check('scheme tests LogbookQAUITests with QA', scheme.includes('buildConfiguration = "QA"') && scheme.includes('BlueprintName = "LogbookQAUITests"'));
check('runner destination is Designed for iPad', runner.includes("-destination 'platform=macOS,variant=Designed for iPad'"));
check('runner scheme and configuration are QA', runner.includes('-scheme App-QA') && runner.includes('-configuration QA'));
check('default command does not pass provisioning updates', !/xcodebuild[\s\S]*-allowProvisioningUpdates/.test(runner.replace(/ALLOW_PROFILE_DOWNLOAD[\s\S]*$/, '')));
check('screenshots are keepAlways attachments', swift.includes('XCTAttachment') && swift.includes('.keepAlways'));
check('production display name is refused', swift.includes('private let productionDisplay = "Borikèn Logbook"') && swift.includes('XCTAssertNotEqual(app.label, productionDisplay,'));
check('production bundle is not launched', swift.includes('com.borikengenetics.logbookapp') && !swift.includes('XCUIApplication(bundleIdentifier: productionBundle).launch'));
check('no webview script injection', !/evaluateJavaScript|WKUserScript/.test(swift));
check('photo test cancels the picker instead of choosing a library photo', swift.includes('Don’t Allow') && swift.includes('No synthetic image was stored'));

if (FAIL.length) {
  console.error(FAIL.length + ' failed');
  process.exit(1);
}
console.log('qa uitest harness checks passed');
