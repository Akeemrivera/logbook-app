'use strict';

/*
  Synthetic full-export / restore photo path.
  Uses a fake IndexedDB and a tiny generated image. Does not read a backup file,
  does not repair a live photo, and does not launch the app.
*/

const fs = require('fs');
const path = require('path');

const ROOT = process.env.LOGBOOK_ROOT || path.join(__dirname, '..');
const FAIL = [];

function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

function installFakeIndexedDB() {
  const dbs = new Map();
  function later(fn) { queueMicrotask(fn); }
  function makeDb(meta) {
    return {
      objectStoreNames: { contains: (name) => meta.stores.has(name) },
      createObjectStore(name) { if (!meta.stores.has(name)) meta.stores.set(name, new Map()); },
      transaction(storeName) {
        const store = meta.stores.get(storeName);
        const tx = { oncomplete: null, onerror: null, error: null };
        const writes = [];
        const api = {
          put(record) { writes.push(() => { store.set(record.id, record); }); },
          get(id) {
            const request = {};
            later(() => {
              request.result = store.has(id) ? store.get(id) : undefined;
              if (request.onsuccess) request.onsuccess();
            });
            return request;
          },
          delete(id) { writes.push(() => { store.delete(id); }); },
          getAllKeys() {
            const request = {};
            later(() => { request.result = [...store.keys()]; if (request.onsuccess) request.onsuccess(); });
            return request;
          },
        };
        later(() => {
          try { writes.forEach((fn) => fn()); if (tx.oncomplete) tx.oncomplete(); }
          catch (error) { tx.error = error; if (tx.onerror) tx.onerror(); }
        });
        return {
          get oncomplete() { return tx.oncomplete; },
          set oncomplete(fn) { tx.oncomplete = fn; },
          get onerror() { return tx.onerror; },
          set onerror(fn) { tx.onerror = fn; },
          get error() { return tx.error; },
          objectStore() { return api; },
        };
      },
      close() {},
    };
  }
  globalThis.indexedDB = {
    open(name, version) {
      const request = { result: null, onsuccess: null, onupgradeneeded: null };
      later(() => {
        if (!dbs.has(name)) dbs.set(name, { stores: new Map(), version: 0 });
        const meta = dbs.get(name);
        request.result = makeDb(meta);
        if ((version || 1) > meta.version) {
          meta.version = version || 1;
          if (request.onupgradeneeded) request.onupgradeneeded();
        }
        if (request.onsuccess) request.onsuccess();
      });
      return request;
    },
  };
}

function shippedCollectIds(state) {
  const ids = new Set();
  const plants = [].concat(state.plants || [], state.breedingPlants || []);
  plants.forEach((plant) => {
    (plant.logs || []).forEach((log) => { if (log && log.photoId) ids.add(log.photoId); });
    if (plant && plant.headerPhotoId) ids.add(plant.headerPhotoId);
  });
  return [...ids];
}

function photoSrc(log, cache) {
  if (!log) return '';
  if (log.photoId && cache.has(log.photoId)) return cache.get(log.photoId);
  if (typeof log.photo === 'string' && (log.photo.startsWith('data:') || log.photo.startsWith('blob:'))) return log.photo;
  return '';
}

function photoTag(log, cache) {
  const src = photoSrc(log, cache);
  if (!src) return 'This photo is saved on the device but could not be loaded.';
  return `<img src="${src}">`;
}

function treePhoto(record, plants, cache, kind) {
  const own = [...(record.logs || [])].filter((log) => log && log.photoId).find((log) => photoSrc(log, cache));
  if (own) return photoSrc(own, cache);
  if (kind === 'mf') {
    const match = plants.find((plant) => String(plant.name || '').toLowerCase() === String(record.name || '').toLowerCase());
    if (match) return treePhoto(match, plants, cache, 'pl');
  }
  return '';
}

async function hydrate(media, state) {
  const cache = new Map();
  for (const id of media.collectIds(state)) {
    const url = await media.objectUrl(id);
    if (url) cache.set(id, url);
  }
  return cache;
}

async function main() {
  const mediaPath = path.join(ROOT, 'media-store.js');
  const appPath = path.join(ROOT, 'app.js');
  const treePath = path.join(ROOT, 'build57.js');
  check('media-store.js present', fs.existsSync(mediaPath), mediaPath);
  if (!fs.existsSync(mediaPath) || !fs.existsSync(appPath)) {
    console.error(FAIL.length + ' failed');
    process.exit(1);
  }
  const mediaSource = fs.readFileSync(mediaPath, 'utf8');
  const app = fs.readFileSync(appPath, 'utf8');
  const tree = fs.existsSync(treePath) ? fs.readFileSync(treePath, 'utf8') : '';
  const phase1 = mediaSource.includes('function plantRecords') && mediaSource.includes('motherFatherPlants');

  if (typeof URL.createObjectURL !== 'function') {
    URL.createObjectURL = (blob) => `blob:synthetic-${blob.size}`;
  }
  installFakeIndexedDB();
  const media = require(mediaPath);
  const deleted = [];
  const realDelete = media.deleteIds.bind(media);
  media.deleteIds = async (ids) => { deleted.push(...(ids || [])); return realDelete(ids); };

  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const dataUrl = `data:image/png;base64,${png.toString('base64')}`;
  const growId = 'grow-photo-1';
  const landraceId = 'landrace-photo-1';
  const state = {
    plants: [{ id: 'grow-1', name: 'Synthetic grow', logs: [{ id: 'obs-1', type: 'Observation', photo: '', photoId: growId }] }],
    breedingPlants: [],
    motherFatherPlants: [{ id: 'mf-1', name: 'Synthetic grow', logs: [], headerPhotoId: '' }, { id: 'landrace-1', name: 'Synthetic landrace', logs: [{ photoId: landraceId }] }],
  };

  check('shipped collectIds includes the grow observation and omits the landrace id', shippedCollectIds(state).includes(growId) && !shippedCollectIds(state).includes(landraceId));
  if (phase1) {
    check('phase1 collectIds also keeps the landrace id', media.collectIds(state).includes(growId) && media.collectIds(state).includes(landraceId));
  } else {
    check('loaded shipped collectIds matches the omission', JSON.stringify(media.collectIds(state).sort()) === JSON.stringify(shippedCollectIds(state).sort()));
  }

  const imported = await media.importPhotos([{ id: growId, mime: 'image/png', name: 'synthetic.png', dataUrl }]);
  const stored = await media.getRecord(growId);
  const storedBytes = Buffer.from(await stored.blob.arrayBuffer());
  check('importPhotos writes the data URL and the readback matches', imported.failed === 0 && storedBytes.equals(png));

  let cache = await hydrate(media, state);
  const log = state.plants[0].logs[0];
  check('hydrate then photoSrc paints an image tag', photoTag(log, cache).startsWith('<img'));
  check('the photo id is still the same after import', log.photoId === growId);

  const uncached = new Map();
  check('a photoId with an empty cache is the could-not-load text', photoTag(log, uncached) === 'This photo is saved on the device but could not be loaded.');
  check('that empty cache does not delete the id', log.photoId === growId && deleted.length === 0);

  const mother = state.motherFatherPlants[0];
  check('an empty mother circle stays empty until the same-name grow photo is hydrated', treePhoto(mother, state.plants, uncached, 'mf') === '');
  check('after hydration the same-name mother circle can reuse the grow url', treePhoto(mother, state.plants, cache, 'mf') === cache.get(growId) && cache.get(growId));
  check('tree source uses photoSrc and falls back to a monogram', tree.includes('photoSrc(l)') && tree.includes('b57-ph mono'));

  const skipped = await media.importPhotos([]);
  check('a backup with no photos array imports nothing and deletes nothing', skipped.imported === 0 && skipped.failed === 0 && deleted.length === 0);
  const bad = await media.importPhotos([{ id: 'bad-photo', dataUrl: 'not-a-data-url' }]);
  check('a photo entry without a data URL is a failure and writes no blob', bad.failed === 1 && !(await media.getRecord('bad-photo')));

  const importFn = app.slice(app.indexOf('function importJSON'), app.indexOf('function applyDeviceSettings'));
  check('full import writes photos, then replaces state, migrates, hydrates, and repaints', importFn.indexOf('importPhotos') < importFn.indexOf('normalizeState') && importFn.indexOf('normalizeState') < importFn.indexOf('migrateInlinePhotos') && importFn.indexOf('migrateInlinePhotos') < importFn.indexOf('hydrateMediaCache') && importFn.indexOf('hydrateMediaCache') < importFn.indexOf('renderAll()'));
  check('a failed photo import still continues into the state replace', /if \(importedPhotos\.failed\)[\s\S]{0,800}showStorageError[\s\S]{0,800}normalizeState/.test(importFn));
  check('import does not prune', !importFn.includes('pruneUnreferencedPhotos'));
  const returnFn = app.slice(app.indexOf('function returnToActive'), app.indexOf('function reopenPlant'));
  check('returnToActive does not import photo bytes', !returnFn.includes('importPhotos') && !returnFn.includes('putDataUrl'));

  const pruneCalls = [...app.matchAll(/pruneUnreferencedPhotos\(/g)].length;
  check('prune runs from its definition plus clear backup history and clear all data', pruneCalls === 3);

  await media.putDataUrl(landraceId, dataUrl);
  const shippedKeep = new Set(shippedCollectIds(state));
  const shippedDrop = (await media.allIds()).filter((id) => !shippedKeep.has(id));
  check('shipped prune keep-set would drop the landrace id and keep the grow id', shippedDrop.includes(landraceId) && !shippedDrop.includes(growId));
  if (phase1) {
    const keep = new Set(media.collectIds(state));
    check('phase1 keep-set retains the landrace id', keep.has(landraceId) && keep.has(growId));
  }

  const other = { id: 'other-plant', name: 'Other', logs: [{ photoId: 'other-photo' }] };
  state.plants.push(other);
  await media.putDataUrl(growId, dataUrl);
  const oneCache = new Map();
  const url = await media.objectUrl(growId);
  if (url) oneCache.set(growId, url);
  check('a one-id rehydrate paints the grow photo and leaves the other plant untouched', photoTag(log, oneCache).startsWith('<img') && other.logs[0].photoId === 'other-photo' && !(await media.getRecord('other-photo')));
  check('this file does not write a repair into app.js', !app.includes('rehydrateOnePhoto'));

  if (FAIL.length) {
    console.error(FAIL.length + ' failed');
    process.exit(1);
  }
  console.log('photo restore regression passed (' + (phase1 ? 'phase1 media-store' : 'shipped media-store') + ')');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
