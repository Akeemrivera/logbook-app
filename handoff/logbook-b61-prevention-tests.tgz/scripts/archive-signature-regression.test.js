'use strict';

/*
  Synthetic archive-writer regression. Reads shipped source. Does not modify it,
  does not launch the app, and does not restore or delete a plant.
  The Nov 6 control that archived the grow record is still unknown.
*/

const fs = require('fs');
const path = require('path');

const ROOT = process.env.LOGBOOK_ROOT || path.join(__dirname, '..');
const FAIL = [];

function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

function read(rel) {
  const file = path.join(ROOT, rel);
  if (!fs.existsSync(file)) {
    check('source present: ' + rel, false, file);
    return '';
  }
  return fs.readFileSync(file, 'utf8');
}

function applyPlantStatus(plant, toStatus) {
  plant.status = toStatus;
  plant.completed = toStatus !== 'active';
  plant.isCompleted = toStatus === 'finished';
  if (toStatus === 'archived') {
    if (!plant.archivedAt) plant.archivedAt = '2026-11-06T12:00:00.000Z';
  }
}

function sliceFn(source, name) {
  const start = source.indexOf('function ' + name);
  if (start < 0) return '';
  const next = source.indexOf('\nfunction ', start + 1);
  return source.slice(start, next < 0 ? start + 1800 : next);
}

const app = read('app.js');
const mobile = read('mobile.js');
const build13 = read('build13.js');
const build61 = read('build61.js');
const plugin = read('ios/App/App/ICloudBackupPlugin.swift');
const beforeHash = app ? require('crypto').createHash('sha256').update(app).digest('hex') : '';

const archivedFn = sliceFn(app, 'applyPlantStatus');
check('applyPlantStatus sets archivedAt only when empty', archivedFn.includes("if (toStatus === 'archived')") && archivedFn.includes('if (!plant.archivedAt) plant.archivedAt'));
check('applyPlantStatus sets completed for every non-active status', archivedFn.includes("plant.completed = toStatus !== 'active'"));
check('applyPlantStatus sets isCompleted only for finished', archivedFn.includes("plant.isCompleted = toStatus === 'finished'"));

const plant = {
  id: 'grow-1',
  name: 'Synthetic grow',
  status: 'active',
  completed: false,
  isCompleted: false,
  archivedAt: '',
  startDate: '2026-01-02',
  vegStartDate: '2026-01-16',
  flowerStartDate: '',
  plannedFlipDate: '',
  flowerFlipDate: '',
  harvestDate: '',
  logs: [{ id: 'log-1' }, { id: 'log-2' }],
};
const snapshot = JSON.parse(JSON.stringify(plant));
applyPlantStatus(plant, 'archived');
const changed = Object.keys(plant).filter((key) => JSON.stringify(plant[key]) !== JSON.stringify(snapshot[key]));
check('archived signature changes status, completed, and archivedAt', JSON.stringify(changed.sort()) === JSON.stringify(['archivedAt', 'completed', 'status']));
check('archived signature leaves dates, harvest, and logs', plant.startDate === '2026-01-02' && plant.vegStartDate === '2026-01-16' && plant.flowerStartDate === '' && plant.plannedFlipDate === '' && plant.harvestDate === '' && plant.logs.length === 2 && plant.isCompleted === false);
check('archived signature matches a logged archive, not a finished plant', plant.status === 'archived' && plant.completed === true && plant.isCompleted === false && Boolean(plant.archivedAt));

const archiveFn = sliceFn(app, 'archivePlant');
check('archivePlant confirms then calls transitionPlant archived', archiveFn.includes("transitionPlant(id, 'archived'") && archiveFn.includes('Archive genetic'));
check('source still does not name which control was used', !/Nov 6 archive cause/.test(app));

const returnFn = sliceFn(app, 'returnToActive');
check('returnToActive is present and not invoked by this test', returnFn.includes("applyPlantStatus(plant, 'active'") && returnFn.includes('Returned to Active production.'));
const returned = JSON.parse(JSON.stringify(plant));
applyPlantStatus(returned, 'active');
check('active status clears completed and keeps archivedAt, dates, and logs', returned.status === 'active' && returned.completed === false && returned.isCompleted === false && returned.archivedAt === plant.archivedAt && returned.startDate === '2026-01-02' && returned.logs.length === 2);

check('mobile profile Archive passes selectedPlantId', mobile.includes('archivePlant(selectedPlantId)'));
const plants = [
  { id: 'open-profile', name: 'Open', status: 'active', completed: false, isCompleted: false, archivedAt: '' },
  { id: 'other-grow', name: 'Other', status: 'active', completed: false, isCompleted: false, archivedAt: '' },
];
let selectedPlantId = 'open-profile';
function archivePlant(id) {
  const row = plants.find((item) => item.id === id);
  if (!row || row.status === 'archived') return;
  applyPlantStatus(row, 'archived');
}
archivePlant(selectedPlantId);
check('hazard: a stale selectedPlantId archives that plant, not another row', plants[0].status === 'archived' && plants[1].status === 'active');
check('that hazard is not claimed as the Nov 6 control', true);

const legacy = sliceFn(app, 'normalizePlant');
check('legacy flowerFlipDate promotion is still in source and was not changed', legacy.includes('if (legacyFlip && !p.flowerStartDate && !p.plannedFlipDate)') && legacy.includes('p.flowerStartDate = legacyFlip'));
function promote(record, today) {
  const copy = { ...record };
  if (copy.flowerFlipDate && !copy.flowerStartDate && !copy.plannedFlipDate) {
    if (copy.flowerFlipDate <= today) copy.flowerStartDate = copy.flowerFlipDate;
    else copy.plannedFlipDate = copy.flowerFlipDate;
  }
  return copy;
}
check('empty flip fields stay empty', promote({ flowerFlipDate: '', flowerStartDate: '', plannedFlipDate: '' }, '2026-11-06').flowerStartDate === '');
check('a past legacy flip would start flower; not applied to a record whose fields were empty', promote({ flowerFlipDate: '2026-10-01', flowerStartDate: '', plannedFlipDate: '' }, '2026-11-06').flowerStartDate === '2026-10-01');
check('a future legacy flip stays planned', promote({ flowerFlipDate: '2026-12-01', flowerStartDate: '', plannedFlipDate: '' }, '2026-11-06').plannedFlipDate === '2026-12-01' && promote({ flowerFlipDate: '2026-12-01', flowerStartDate: '', plannedFlipDate: '' }, '2026-11-06').flowerStartDate === '');

const isFx = (value) => /^fx-/.test(String(value || '')) || /^(mf|pl|bp|pr):fx-/.test(String(value || ''));
check('fx- cleanup does not match a normal plant id', isFx('11111111-2222-4333-8444-555555555555') === false && isFx('fx-sample') === true);
check('fx- cleanup source is limited to capacitor and ionic', build61.includes("/^(capacitor|ionic):$/.test(location.protocol)") && build61.includes("const isFx = (v) => /^fx-/.test"));

check('automatic backup name is the date only', build13.includes("const name = `${ICLOUD_PREFIX}${todayKey()}.json`") && build13.includes("const ICLOUD_PREFIX = 'boriken-logbook-backup-'") && build13.includes('const ICLOUD_KEEP = 7'));
check('write replaces the same filename', plugin.includes('.forReplacing'), 'ICloudBackupPlugin.swift missing .forReplacing');
check('prune keeps the newest names and deletes the rest', plugin.includes('sorted(by: >)') && plugin.includes('names.dropFirst(keep)'));

function backupName(day) { return `boriken-logbook-backup-${day}.json`; }
const files = new Map();
function writeDay(day, body) { files.set(backupName(day), body); }
function prune(keep) {
  const names = [...files.keys()].filter((name) => name.startsWith('boriken-logbook-backup-') && name.endsWith('.json')).sort((a, b) => (a < b ? 1 : -1));
  names.slice(keep).forEach((name) => files.delete(name));
}
writeDay('2026-11-06', 'morning');
writeDay('2026-11-06', 'evening');
check('two backups on one date leave one file and the later body', files.size === 1 && files.get(backupName('2026-11-06')) === 'evening');
for (let day = 1; day <= 8; day += 1) writeDay(`2026-11-${String(day).padStart(2, '0')}`, 'x');
prune(7);
check('eight dated names prune to the newest seven', files.size === 7 && !files.has(backupName('2026-11-01')) && files.has(backupName('2026-11-08')));

const after = read('app.js');
check('this test did not modify app.js', after && require('crypto').createHash('sha256').update(after).digest('hex') === beforeHash);

if (FAIL.length) {
  console.error(FAIL.length + ' failed');
  process.exit(1);
}
console.log('archive signature regression passed');
