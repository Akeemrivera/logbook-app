#!/bin/zsh
# Build and run LogbookQAUITests on this Mac, Designed for iPad, QA bundle only.
# Does not launch com.borikengenetics.logbookapp and does not pass -allowProvisioningUpdates
# unless ALLOW_PROFILE_DOWNLOAD=1. Never set that if Xcode asks to register a device.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$PWD
REAL=com.borikengenetics.logbookapp
QA=com.borikengenetics.logbookapp.qa
APP_HINT="${QA_APP:-$ROOT/build/qa-derived/Build/Products/QA-iphoneos/App.app}"

if [[ -f "$APP_HINT/Info.plist" ]]; then
  ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_HINT/Info.plist")
  if [[ "$ID" != "$QA" ]]; then
    echo "Refusing: $APP_HINT is $ID"
    exit 4
  fi
  zsh "$ROOT/rig-guard.sh" "$APP_HINT" mac
fi

EXTRA=()
if [[ "${ALLOW_PROFILE_DOWNLOAD:-}" == "1" ]]; then
  echo "ALLOW_PROFILE_DOWNLOAD=1 adds -allowProvisioningUpdates."
  echo "Stop immediately if Xcode asks to register a device. The Mac 00008142-00100936266B401C is already registered."
  EXTRA+=(-allowProvisioningUpdates)
fi

rm -rf "$ROOT/build/qa-uitest.xcresult"
xcodebuild test \
  -project "$ROOT/ios/App/App.xcodeproj" \
  -scheme App-QA \
  -configuration QA \
  -destination 'platform=macOS,variant=Designed for iPad' \
  -derivedDataPath "$ROOT/build/qa-derived" \
  -resultBundlePath "$ROOT/build/qa-uitest.xcresult" \
  -only-testing:LogbookQAUITests \
  CODE_SIGN_STYLE=Automatic \
  DEVELOPMENT_TEAM=2Z94YL957X \
  "${EXTRA[@]}"

echo "xcresult: $ROOT/build/qa-uitest.xcresult"
mkdir -p "$ROOT/build/qa-screenshots"
if xcrun xcresulttool export attachments --path "$ROOT/build/qa-uitest.xcresult" --output-path "$ROOT/build/qa-screenshots"; then
  echo "screenshots: $ROOT/build/qa-screenshots"
else
  echo "This Xcode has no attachment export helper. Open build/qa-uitest.xcresult for the screenshots."
fi
echo "Did not launch $REAL."
