'use strict';

/*
  Fail-closed check for a running production Logbook before any QA launch.
  Identity is the bundle id, not the .app path. Designed for iPad often runs
  as App inside a wrapper, so a pgrep for "Borikèn Logbook.app/" can miss it.
  This file does not launch, activate, or quit any app.
*/

const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const PROD = 'com.borikengenetics.logbookapp';
const QA = 'com.borikengenetics.logbookapp.qa';

function fold(value) {
  return String(value || '').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
}

function normId(value) {
  return String(value || '').trim().toLowerCase();
}

function isProd(value) {
  return normId(value) === PROD;
}

function isQa(value) {
  return normId(value) === QA;
}

function idsOf(app) {
  return [app && app.bundleId, ...((app && app.bundleIds) || [])].map(normId).filter(Boolean);
}

function suspect(app) {
  const name = fold(app && app.name);
  const filePath = fold(app && app.path);
  if (name === 'boriken logbook' || name.startsWith('boriken logbook ')) return true;
  if (filePath.includes('/boriken logbook.app')) return true;
  if (/\/logbook\.app(\/|$)/.test(filePath)) return true;
  const parts = String((app && app.path) || '').split(/[/\\]/);
  return parts.some((part) => normId(part) === PROD);
}

function sourceOk(source) {
  return Boolean(source && source.ok === true && source.complete === true && Array.isArray(source.apps));
}

function decide(obs) {
  const sources = [
    ['lsappinfo', obs && obs.lsappinfo],
    ['system-events', obs && obs.systemEvents],
  ];
  const apps = [];
  const uncertain = [];
  sources.forEach(([name, source]) => {
    if (source && Array.isArray(source.apps)) apps.push(...source.apps);
    if (!sourceOk(source)) uncertain.push(name);
  });
  // A parsed production bundle id blocks even when another row or the other query is incomplete.
  for (const app of apps) {
    if (idsOf(app).some(isProd)) return { ok: false, reason: 'production Logbook is running' };
  }
  for (const app of apps) {
    if (suspect(app) && idsOf(app).length === 0) {
      return { ok: false, reason: 'a Logbook-like app has no readable bundle id' };
    }
  }
  if (uncertain.length) return { ok: false, reason: 'running-app identity uncertain: ' + uncertain.join(', ') };
  return { ok: true, reason: 'no production Logbook identified' };
}

function quotedBundleIds(text) {
  const ids = [];
  const re = /(?:bundleID|CFBundleIdentifier)="([^"]*)"/g;
  let match;
  const body = String(text || '');
  while ((match = re.exec(body))) ids.push(match[1]);
  return ids;
}

function parseLsappinfo(text) {
  const apps = [];
  let cur = null;
  for (const line of String(text || '').split(/\r?\n/)) {
    const named = line.match(/"([^"]*)"/);
    const bid = line.match(/(?:bundleID|CFBundleIdentifier)="([^"]*)"/);
    const bpath = line.match(/bundle path="([^"]*)"/);
    const epath = line.match(/executable path="([^"]*)"/);
    if (/ASN:/.test(line)) {
      cur = { name: named ? named[1] : '', bundleId: '', path: '', bundleIds: [] };
      apps.push(cur);
    }
    if (!cur) continue;
    if (bid && !cur.bundleId) cur.bundleId = bid[1];
    if (bpath) cur.path = bpath[1];
    else if (epath && !cur.path) cur.path = epath[1];
  }
  const seen = new Set(apps.map((app) => normId(app.bundleId)).filter(Boolean));
  quotedBundleIds(text).forEach((id) => {
    if (seen.has(normId(id))) return;
    seen.add(normId(id));
    apps.push({ name: '', bundleId: id, path: '', bundleIds: [] });
  });
  // One nameless helper row must not hide a bundle id parsed from another row.
  const complete = quotedBundleIds(text).some((id) => normId(id));
  return { ok: true, complete, apps };
}

function parseSystemEvents(text) {
  const apps = [];
  const lines = String(text || '').split(/\r?\n/).filter((line) => line.trim() !== '');
  if (!lines.length) return { ok: true, complete: false, apps: [] };
  let bad = 0;
  for (const line of lines) {
    const parts = line.split('\t');
    if (parts.length < 3) { bad += 1; continue; }
    apps.push({ bundleId: parts[0], path: parts[1], name: parts.slice(2).join('\t'), bundleIds: [] });
  }
  if (!apps.length) return { ok: false, complete: false, apps: [], error: 'system events rows were not identity, path, and name' };
  return { ok: true, complete: bad === 0, apps };
}

function readXmlBundleId(file) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    const match = text.match(/<key>CFBundleIdentifier<\/key>\s*<string>([^<]*)<\/string>/);
    return match ? match[1].trim() : '';
  } catch (error) {
    return '';
  }
}

function bundleIdsAlong(start) {
  const found = [];
  let dir = start;
  for (let i = 0; i < 8 && dir && dir !== path.dirname(dir); i += 1) {
    const candidates = [
      path.join(dir, 'Info.plist'),
      path.join(dir, 'Contents', 'Info.plist'),
      path.join(dir, 'Wrapper', 'App.app', 'Info.plist'),
    ];
    candidates.forEach((file) => {
      const id = readXmlBundleId(file);
      if (id) found.push(id);
    });
    dir = path.dirname(dir);
  }
  return found;
}

function run(cmd, args) {
  const result = spawnSync(cmd, args, { encoding: 'utf8', timeout: 20000, maxBuffer: 32 * 1024 * 1024 });
  if (!result || result.error || result.status !== 0) {
    return { ok: false, complete: false, apps: [], error: (result && result.error && result.error.message) || cmd + ' failed' };
  }
  return { ok: true, stdout: result.stdout || '' };
}

function collectLive() {
  const listed = run('lsappinfo', ['list']);
  const lsappinfo = listed.ok ? parseLsappinfo(listed.stdout) : { ok: false, complete: false, apps: [], error: listed.error };
  const script = [
    'tell application "System Events"',
    'set out to ""',
    'repeat with p in application processes',
    'set bid to ""',
    'set pth to ""',
    'set nm to ""',
    'try',
    'set bid to bundle identifier of p',
    'end try',
    'try',
    'set pth to POSIX path of (application file of p as alias)',
    'end try',
    'try',
    'set nm to name of p',
    'end try',
    'set out to out & bid & tab & pth & tab & nm & linefeed',
    'end repeat',
    'return out',
    'end tell',
  ].join('\n');
  const events = run('osascript', ['-e', script]);
  const systemEvents = events.ok ? parseSystemEvents(events.stdout) : { ok: false, complete: false, apps: [], error: events.error };
  (systemEvents.apps || []).forEach((app) => {
    app.bundleIds = bundleIdsAlong(app.path);
  });
  return { lsappinfo, systemEvents };
}

function main() {
  const obs = collectLive();
  const result = decide(obs);
  if (!result.ok) {
    console.error('RIG-GUARD: ' + result.reason);
    process.exit(4);
  }
  console.log('RIG-GUARD: ' + result.reason);
}

module.exports = {
  PROD,
  QA,
  decide,
  parseLsappinfo,
  parseSystemEvents,
  bundleIdsAlong,
  suspect,
  isProd,
  isQa,
};

if (require.main === module) main();
