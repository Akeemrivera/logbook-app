'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const guard = require('./rig-guard-running.js');

const FAIL = [];
function check(name, ok, detail) {
  if (ok) console.log('PASS', name);
  else {
    FAIL.push(name);
    console.error('FAIL', name, detail || '');
  }
}

const finder = { name: 'Finder', bundleId: 'com.apple.Finder', path: '/System/Applications/Finder.app', bundleIds: [] };

function obs(extraLs, extraSe) {
  return {
    lsappinfo: { ok: true, complete: true, apps: [finder].concat(extraLs || []) },
    systemEvents: { ok: true, complete: true, apps: [finder].concat(extraSe || []) },
  };
}

check('nothing identified as production is clear', guard.decide(obs()).ok === true);
check('exact production bundle id blocks', guard.decide(obs([], [{ name: 'App', bundleId: guard.PROD, path: '/private/var/folders/x/App' }])).ok === false);
check('QA bundle id does not count as production', guard.decide(obs([], [{ name: 'Borikèn Logbook QA', bundleId: guard.QA, path: '/Applications/Borikèn Logbook QA.app' }])).ok === true);
check('a longer id is not treated as the production id', guard.isProd(guard.QA) === false && guard.isQa(guard.QA) === true);

const renamed = { name: 'Garden Notes', bundleId: guard.PROD, path: '/Users/a/Applications/Garden Notes.app', bundleIds: [] };
check('a renamed app still blocks when its bundle id is production', guard.decide(obs([renamed])).reason === 'production Logbook is running');

const nfd = 'Borike\u0300n Logbook';
check('an accent-decomposed Logbook name with no bundle id blocks', guard.decide(obs([], [{ name: nfd, bundleId: '', path: '/Applications/' + nfd + '.app' }])).ok === false);
check('the same decomposed name is clear when the bundle id is QA', guard.decide(obs([], [{ name: nfd, bundleId: guard.QA, path: '/Applications/' + nfd + '.app' }])).ok === true);

const wrapper = '/Users/a/Applications/Boriken Logbook.app/Wrapper/App.app/App';
check('an iOS-on-Mac wrapper path with the production id blocks even without the display name in argv', guard.decide(obs([{ name: 'App', bundleId: guard.PROD, path: wrapper }])).ok === false);
check('the same wrapper path is clear for the QA id', guard.decide(obs([{ name: 'App', bundleId: guard.QA, path: wrapper }])).ok === true);
check('Logbook.app with no readable bundle id blocks', guard.decide(obs([], [{ name: 'App', bundleId: '', path: '/Applications/Logbook.app' }])).ok === false);
check('Logbook.app with a different readable bundle id is clear', guard.decide(obs([], [{ name: 'App', bundleId: 'com.example.other', path: '/Applications/Logbook.app' }])).ok === true);
check('the production container path blocks', guard.decide(obs([], [{ name: 'App', bundleId: '', path: '/Users/a/Library/Containers/' + guard.PROD + '/Data' }])).ok === false);
check('the QA container path does not block by itself', guard.decide(obs([], [{ name: 'App', bundleId: guard.QA, path: '/Users/a/Library/Containers/' + guard.QA + '/Data' }])).ok === true);
check('production id in only one of the two lists blocks', guard.decide(obs([{ name: 'App', bundleId: guard.PROD, path: wrapper }], [])).ok === false);
check('a failed lsappinfo query blocks', guard.decide({ lsappinfo: { ok: false, complete: false, apps: [] }, systemEvents: obs().systemEvents }).reason === 'running-app identity uncertain');
check('a failed System Events query blocks', guard.decide({ lsappinfo: obs().lsappinfo, systemEvents: { ok: false, complete: false, apps: [] } }).ok === false);
check('an empty successful-looking query is still uncertain', guard.decide({ lsappinfo: { ok: true, complete: false, apps: [] }, systemEvents: obs().systemEvents }).ok === false);
check('uppercase production id blocks', guard.decide(obs([], [{ name: 'App', bundleId: guard.PROD.toUpperCase(), path: '/tmp/App' }])).ok === false);

const parsed = guard.parseLsappinfo([
  '1) "App" ASN:0x0-0x1:',
  '    bundleID="' + guard.PROD + '"',
  '    bundle path="' + wrapper + '"',
].join('\n'));
check('lsappinfo text for the wrapper resolves to production', parsed.complete === true && guard.decide({ lsappinfo: parsed, systemEvents: obs().systemEvents }).ok === false);

const events = guard.parseSystemEvents(guard.QA + '\t/Applications/Boriken Logbook QA.app\tBoriken Logbook QA\n');
check('system events rows parse bundle id, path, and name', events.complete === true && events.apps[0].bundleId === guard.QA);
check('a short system events row is uncertain', guard.parseSystemEvents('only-one-field\n').ok === false);

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rig-guard-'));
const renamedApp = path.join(root, 'Garden Notes.app');
const wrapperApp = path.join(root, 'Boriken Logbook.app', 'Wrapper', 'App.app');
fs.mkdirSync(path.join(renamedApp, 'Contents'), { recursive: true });
fs.mkdirSync(wrapperApp, { recursive: true });
const plist = (id) => `<?xml version="1.0" encoding="UTF-8"?>\n<plist version="1.0"><dict><key>CFBundleIdentifier</key><string>${id}</string></dict></plist>\n`;
fs.writeFileSync(path.join(renamedApp, 'Contents', 'Info.plist'), plist(guard.PROD));
fs.writeFileSync(path.join(wrapperApp, 'Info.plist'), plist(guard.QA));
check('a renamed bundle path reads the production id from its plist', guard.bundleIdsAlong(renamedApp).includes(guard.PROD));
check('an iOS-on-Mac wrapper path reads the inner Info.plist', guard.bundleIdsAlong(path.join(wrapperApp, 'App')).includes(guard.QA));

const script = fs.readFileSync(path.join(__dirname, '..', 'rig-guard.sh'), 'utf8');
check('the guard no longer treats a display-name path search as proof the app is closed', !script.includes('pgrep'));
check('the guard asks the running-app check and does not quit or launch an app', script.includes('scripts/rig-guard-running.js') && !/killall|osascript/.test(script));

const live = spawnSync(process.execPath, [path.join(__dirname, 'rig-guard-running.js')], { encoding: 'utf8' });
check('live check fails closed where running-app tools are missing or unusable', live.status === 4);

if (FAIL.length) {
  console.error(FAIL.length + ' failed');
  process.exit(1);
}
console.log('rig guard running checks passed');
