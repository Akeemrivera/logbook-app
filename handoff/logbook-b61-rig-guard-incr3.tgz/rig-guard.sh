#!/bin/zsh
# b61 rig guard. Every shot / QA rig must call this before installing or opening a test build.
# usage: rig-guard.sh <path/to/App.app or wrapper .app> <sim|mac> [simulator-udid]
# - mac: refuses any build whose bundle id is the real one (com.borikengenetics.logbookapp). A Mac "Designed for iPad" build
#   with the real id shares ~/Library/Containers/com.borikengenetics.logbookapp with Elio's installed app = his real data.
# - sim: the target must be a simulator udid (never a physical device).
REAL=com.borikengenetics.logbookapp; APP=$1; T=$2; U=$3
P=$APP/Info.plist; [ -f $APP/Wrapper/App.app/Info.plist ] && P=$APP/Wrapper/App.app/Info.plist
[ -f "$APP/Wrapper/App.app/Info.plist" ] && APP=$APP/Wrapper/App.app
ID=$(/usr/libexec/PlistBuddy -c "Print :CFBundleIdentifier" "$P" 2>/dev/null)
[ "$ID" = "$REAL" ] && { echo "RIG-GUARD: refusing test run with the real bundle id $REAL (would use live data or production iCloud)"; exit 4; }
check_ents() {
  local ent
  ent=$(codesign -d --entitlements :- "$1" 2>/dev/null) || { echo "RIG-GUARD: could not read the code signature"; exit 4; }
  echo "$ent" | grep -q 'iCloud.com.borikengenetics.logbookapp' && { echo "RIG-GUARD: refusing production iCloud container"; exit 4; }
  echo "$ent" | grep -q 'keychain-access-groups' && { echo "RIG-GUARD: refusing keychain sharing"; exit 4; }
  echo "$ent" | grep -q 'application-groups' && { echo "RIG-GUARD: refusing an app group"; exit 4; }
  echo "$ent" | grep -q 'ubiquity-container-identifiers' && { echo "RIG-GUARD: refusing an iCloud Drive container"; exit 4; }
}
if [ "$T" = mac ]; then
  # Bundle id, not the .app path. Designed for iPad often runs as App inside a wrapper,
  # so a search for "Borikèn Logbook.app/" can miss an open production window.
  # Uncertainty, and a production bundle id under any name or path, both stop the run.
  # This does not quit or launch the production app.
  DIR=${0:A:h}
  node "$DIR/scripts/rig-guard-running.js" || { echo "RIG-GUARD: running-app check failed closed"; exit 4; }
  check_ents "$APP"
elif [ "$T" = sim ]; then
  xcrun simctl list devices | grep -q "($U)" || { echo "RIG-GUARD: $U is not a simulator"; exit 4; }
  check_ents "$APP"
else echo "RIG-GUARD: target must be sim or mac"; exit 4; fi
echo "RIG-GUARD ok: $ID on $T"
